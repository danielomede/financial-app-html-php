<?php
$servername = "localhost";
$username = "gatehou2_admin";
$password = "jaykay007";
$dbname = "gatehou2_main";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
 #echo "Connected successfully";
?>