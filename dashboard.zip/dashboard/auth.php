<?php
include 'config.php';
session_start();
if(!isset($_SESSION["email"])){
header("Location: app-login.php ");
exit(); }

$user = $_SESSION['email'];
$query = "SELECT * FROM users WHERE email = '$user'";
$result = mysqli_query($conn,$query);
$row = mysqli_fetch_array($result);
$fullname = $row['fullname'];
$balance = $row['balance'];
$accountnumber = $row['accountnumber'];
$userid = $row['id'];
?>
